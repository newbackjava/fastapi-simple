function call() {
    alert("welcome!! fastAPI!!");
}