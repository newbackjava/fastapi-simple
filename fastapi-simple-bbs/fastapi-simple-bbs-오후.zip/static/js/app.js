function call() {
    alert("외부 js call()함수 호출됨.!!")
}